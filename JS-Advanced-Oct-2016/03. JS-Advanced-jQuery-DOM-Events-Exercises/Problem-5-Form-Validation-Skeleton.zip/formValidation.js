function solve() {
    return function(){
       //Write your code her
    }
}
